package ru.startandroid.develop.redwhite;

public interface FragmentLeftCallBack {
    void onFragmentClicked();

    void onStartLossActivity();

    void startWinnerActivity();

}
